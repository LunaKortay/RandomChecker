import matplotlib.pyplot as plt
import json
import os

from collections import Counter

base_dir = os.path.dirname(__file__)
json_file = os.path.join(base_dir, "numbers.json")

with open(json_file, "r") as f:
    data = json.load(f)

number_counts = Counter(data)

numbers = list(number_counts.keys())
counts = list(number_counts.values())

plt.bar(numbers, counts, color="blue")

plt.xlabel("Number")
plt.ylabel("Count")
plt.title("Distribution of Numbers in Dataset")

plt.xticks(numbers, rotation=90)
plt.show()
