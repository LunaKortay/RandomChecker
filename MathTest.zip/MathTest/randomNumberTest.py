import random
import json
import os


base_dir = os.path.dirname(__file__)
json_file = os.path.join(base_dir, "numbers.json")
print(base_dir)

with open(json_file, "r") as f:
    data = json.load(f)


numberList = []
numberList.extend(data)


for i in range(0, 10000):
    randomGeneratedNumber: int = random.randint(1, 100)
    numberList.append(randomGeneratedNumber)

with open(json_file, "w") as f:
    json.dump(numberList, f, indent=4)

print(numberList)
